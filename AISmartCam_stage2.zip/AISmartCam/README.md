# AI Smart Cam — مرحله ۱ (نمونه اولیه)
1. Android Studio (Koala یا جدیدتر) → Open → پوشه AISmartCam. صبر کنید Gradle Sync تمام شود (اینترنت لازم است).
2. گوشی: Developer options و USB debugging را روشن کنید و وصل کنید.
3. Run ▶ یا Build > Build APK(s). خروجی: app/build/outputs/apk/debug/app-debug.apk
