package com.smartcam.ai

import android.graphics.Bitmap
import android.opengl.*
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** همان شیدر پیش‌نمایش را روی عکس با رزولوشن کامل اجرا می‌کند (EGL آفلاین)، پس خروجی با پیش‌نمایش یکی است. */
object OfflineProcessor {
    fun process(src: Bitmap, p: FloatArray, mask: MaskData?, lut: LutData?, lutMix: Float): Bitmap {
        val dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val v = IntArray(2); EGL14.eglInitialize(dpy, v, 0, v, 1)
        val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, intArrayOf(EGL14.EGL_RENDERABLE_TYPE, EGL14.EGL_OPENGL_ES2_BIT, EGL14.EGL_SURFACE_TYPE, EGL14.EGL_PBUFFER_BIT,
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8, EGL14.EGL_NONE), 0, cfgs, 0, 1, n, 0)
        val ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 2, EGL14.EGL_NONE), 0)
        val surf = EGL14.eglCreatePbufferSurface(dpy, cfgs[0], intArrayOf(EGL14.EGL_WIDTH, 1, EGL14.EGL_HEIGHT, 1, EGL14.EGL_NONE), 0)
        EGL14.eglMakeCurrent(dpy, surf, surf, ctx)
        try {
            val mx = IntArray(1); GLES20.glGetIntegerv(GLES20.GL_MAX_TEXTURE_SIZE, mx, 0)
            val lim = minOf(mx[0], 4096)
            var bmp = src
            if (maxOf(src.width, src.height) > lim) {
                val k = lim.toFloat() / maxOf(src.width, src.height)
                bmp = Bitmap.createScaledBitmap(src, (src.width * k).toInt(), (src.height * k).toInt(), true)
            }
            val w = bmp.width; val h = bmp.height
            val pipe = Pipeline(false)
            val srcTex = Gl.tex2d(); GLUtils.texImage2D(GLES20.GL_TEXTURE_2D, 0, bmp, 0)
            val maskTex = Gl.tex2d(); if (mask != null) Gl.uploadMask(maskTex, mask) else Gl.blackPixel(maskTex)
            val lutTex = Gl.tex2d(); if (lut != null) Gl.uploadLut(lutTex, lut) else Gl.blackPixel(lutTex)
            val outTex = Gl.tex2d()
            GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, w, h, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
            val f = IntArray(1); GLES20.glGenFramebuffers(1, f, 0)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, f[0])
            GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, outTex, 0)
            GLES20.glViewport(0, 0, w, h)
            pipe.draw(p, Gl.quad(Gl.UV[0]!!), null, srcTex, maskTex, lutTex, false, mask != null,
                if (lut != null) lutMix else 0f, lut?.size ?: 2, false, false, true)
            val buf = ByteBuffer.allocateDirect(w * h * 4).order(ByteOrder.nativeOrder())
            GLES20.glReadPixels(0, 0, w, h, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, buf)
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); out.copyPixelsFromBuffer(buf)
            return out
        } finally {
            EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
            EGL14.eglDestroySurface(dpy, surf); EGL14.eglDestroyContext(dpy, ctx); EGL14.eglTerminate(dpy)
        }
    }
}
