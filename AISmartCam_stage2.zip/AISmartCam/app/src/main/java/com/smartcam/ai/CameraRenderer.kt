package com.smartcam.ai

import android.graphics.SurfaceTexture
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGL10
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.egl.EGLDisplay
import javax.microedition.khronos.opengles.GL10

/** انتخاب EGLConfig با پرچم recordable تا ضبط ویدیو از همان context ممکن باشد. */
class RecordableChooser : GLSurfaceView.EGLConfigChooser {
    override fun chooseConfig(egl: EGL10, display: EGLDisplay): EGLConfig {
        fun pick(rec: Boolean): EGLConfig? {
            val a = ArrayList<Int>().apply {
                addAll(listOf(EGL10.EGL_RED_SIZE, 8, EGL10.EGL_GREEN_SIZE, 8, EGL10.EGL_BLUE_SIZE, 8, EGL10.EGL_ALPHA_SIZE, 8, EGL10.EGL_RENDERABLE_TYPE, 4))
                if (rec) addAll(listOf(0x3142, 1)); add(EGL10.EGL_NONE)
            }.toIntArray()
            val cfgs = arrayOfNulls<EGLConfig>(1); val n = IntArray(1)
            egl.eglChooseConfig(display, a, cfgs, 1, n)
            return if (n[0] > 0) cfgs[0] else null
        }
        return pick(true) ?: pick(false) ?: throw RuntimeException("No EGL config")
    }
}

class CameraRenderer(private val onReady: (SurfaceTexture) -> Unit) : GLSurfaceView.Renderer {
    @Volatile var target = ColorProfile().v.copyOf()
    @Volatile var bypass = false
    @Volatile var rotation = 90
    @Volatile var zebra = false
    @Volatile var falseColor = false
    @Volatile var lutMix = 0f
    @Volatile var pendingMask: MaskData? = null
    @Volatile var pendingLut: LutData? = null
    @Volatile var clearLut = false
    @Volatile var recorder: VideoRecorder? = null
    @Volatile var onHistogram: ((FloatArray, Float) -> Unit)? = null

    private val cur = ColorProfile().v.copyOf()
    private lateinit var pipe: Pipeline
    private var camTex = 0; private var maskTex = 0; private var lutTex = 0
    private var hasMask = false; private var lutSize = 2
    private var st: SurfaceTexture? = null
    private val stm = FloatArray(16)
    private var w = 1; private var h = 1
    private var quad: FloatBuffer = Gl.quad(Gl.UV[90]!!); private var quadRot = 90
    private var fbo = 0; private var fboTex = 0; private var frame = 0
    private val HW = 96; private val HH = 128
    private val hbuf = ByteBuffer.allocateDirect(HW * HH * 4)

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        pipe = Pipeline(true)
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0); camTex = t[0]
        GLES20.glBindTexture(Gl.OES, camTex)
        GLES20.glTexParameteri(Gl.OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(Gl.OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(Gl.OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(Gl.OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        maskTex = Gl.tex2d(); Gl.blackPixel(maskTex); hasMask = false
        lutTex = Gl.tex2d(); Gl.blackPixel(lutTex)
        fboTex = Gl.tex2d()
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGBA, HW, HH, 0, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, null)
        val f = IntArray(1); GLES20.glGenFramebuffers(1, f, 0); fbo = f[0]
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo)
        GLES20.glFramebufferTexture2D(GLES20.GL_FRAMEBUFFER, GLES20.GL_COLOR_ATTACHMENT0, GLES20.GL_TEXTURE_2D, fboTex, 0)
        GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
        st = SurfaceTexture(camTex); onReady(st!!)
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) { w = width; h = height }

    private fun scene(overlay: Boolean) {
        pipe.draw(cur, quad, stm, camTex, maskTex, lutTex, bypass && overlay, hasMask,
            if (lutSize > 2 || lutMix > 0f) lutMix else 0f, lutSize, overlay && zebra, overlay && falseColor, false)
    }

    override fun onDrawFrame(gl: GL10?) {
        val s = st ?: return
        try { s.updateTexImage(); s.getTransformMatrix(stm) } catch (_: Exception) { return }
        if (quadRot != rotation) { quadRot = rotation; quad = Gl.quad(Gl.UV[quadRot] ?: Gl.UV[90]!!) }
        pendingMask?.let { pendingMask = null; Gl.uploadMask(maskTex, it); hasMask = true }
        pendingLut?.let { pendingLut = null; Gl.uploadLut(lutTex, it); lutSize = it.size }
        if (clearLut) { clearLut = false; lutSize = 2; Gl.blackPixel(lutTex) }
        val tgt = target
        for (i in cur.indices) cur[i] += (tgt[i] - cur[i]) * 0.12f

        frame++
        if (frame % 4 == 0 && onHistogram != null) {
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, fbo); GLES20.glViewport(0, 0, HW, HH)
            scene(false)
            hbuf.position(0); GLES20.glReadPixels(0, 0, HW, HH, GLES20.GL_RGBA, GLES20.GL_UNSIGNED_BYTE, hbuf)
            GLES20.glBindFramebuffer(GLES20.GL_FRAMEBUFFER, 0)
            val bins = FloatArray(64); var clip = 0
            for (i in 0 until HW * HH) {
                val r = hbuf.get(i * 4).toInt() and 255; val g = hbuf.get(i * 4 + 1).toInt() and 255; val b = hbuf.get(i * 4 + 2).toInt() and 255
                val l = (0.2126f * r + 0.7152f * g + 0.0722f * b) / 255f
                bins[(l * 63f).toInt().coerceIn(0, 63)] += 1f; if (l > 0.98f) clip++
            }
            val mx = bins.max(); if (mx > 0) for (i in bins.indices) bins[i] /= mx
            onHistogram?.invoke(bins, clip * 100f / (HW * HH))
        }
        GLES20.glViewport(0, 0, w, h)
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        scene(true)

        val r = recorder
        if (r != null) {
            r.encodeFrame(s.timestamp) { scene(false) }
            GLES20.glViewport(0, 0, w, h)
            if (r.finished) recorder = null
        }
    }
}
