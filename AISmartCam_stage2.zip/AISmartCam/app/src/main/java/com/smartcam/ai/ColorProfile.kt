package com.smartcam.ai

import org.json.JSONObject

/** پروفایل پردازش رنگ. خروجی AI (JSON) هم از همین ساختار عبور و اعتبارسنجی می‌شود. */
class ColorProfile(val v: FloatArray = FloatArray(N).also { it[SKIN] = 0.6f }) {

    fun add(i: Int, d: Float) { v[i] = (v[i] + d).coerceIn(MIN[i], MAX[i]) }
    fun set(i: Int, x: Float) { v[i] = x.coerceIn(MIN[i], MAX[i]) }
    fun copy() = ColorProfile(v.copyOf())

    fun toJson(): String = JSONObject().also { o -> for (i in 0 until N) o.put(NAMES[i], v[i].toDouble()) }.toString()

    companion object {
        const val EXPOSURE = 0; const val TEMP = 1; const val TINT = 2; const val CONTRAST = 3
        const val SAT = 4; const val VIB = 5; const val HIGH = 6; const val SHAD = 7
        const val GREEN = 8; const val BLUE = 9; const val SKIN = 10; const val WARMSKIN = 11
        const val N = 12
        val NAMES = arrayOf("exposure", "temperature", "tint", "contrast", "saturation", "vibrance",
            "highlights", "shadows", "green", "blue", "skinProtect", "warmSkin")
        val MIN = floatArrayOf(-2f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, -1f, 0f, -1f)
        val MAX = floatArrayOf(2f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f, 1f)

        /** اعتبارسنجی JSON (برای خروجی LLM در مرحله بعد): کلیدهای ناشناخته نادیده، مقادیر clamp می‌شوند. */
        fun fromJson(s: String): ColorProfile? = try {
            val o = JSONObject(s); val p = ColorProfile()
            for (i in 0 until N) if (o.has(NAMES[i])) p.set(i, o.getDouble(NAMES[i]).toFloat())
            p
        } catch (e: Exception) { null }

        /** ادغام و اعتبارسنجی: کلیدهای ناشناخته نادیده، مقادیر در بازهٔ مجاز clamp می‌شوند. */
        fun fromJsonMerge(base: ColorProfile, o: JSONObject): ColorProfile {
            val p = base.copy()
            for (i in 0 until N) if (o.has(NAMES[i])) p.set(i, o.getDouble(NAMES[i]).toFloat())
            return p
        }

        fun auto() = ColorProfile().also {
            it.set(CONTRAST, 0.08f); it.set(VIB, 0.15f); it.set(HIGH, -0.2f); it.set(SHAD, 0.15f); it.set(SKIN, 0.8f)
        }
    }
}

val PRESET_NAMES = listOf("Natural", "Teal-Orange", "Warm Film", "Moody", "Vivid")
fun presetProfile(name: String): ColorProfile {
    val p = ColorProfile()
    when (name) {
        "Teal-Orange" -> { p.set(ColorProfile.TEMP, 0.12f); p.set(ColorProfile.CONTRAST, 0.2f); p.set(ColorProfile.SHAD, -0.1f); p.set(ColorProfile.BLUE, 0.3f); p.set(ColorProfile.WARMSKIN, 0.3f) }
        "Warm Film" -> { p.set(ColorProfile.TEMP, 0.25f); p.set(ColorProfile.CONTRAST, 0.15f); p.set(ColorProfile.SAT, -0.1f); p.set(ColorProfile.HIGH, -0.2f); p.set(ColorProfile.SHAD, 0.1f) }
        "Moody" -> { p.set(ColorProfile.EXPOSURE, -0.2f); p.set(ColorProfile.CONTRAST, 0.3f); p.set(ColorProfile.SAT, -0.25f); p.set(ColorProfile.SHAD, -0.3f) }
        "Vivid" -> { p.set(ColorProfile.VIB, 0.3f); p.set(ColorProfile.SAT, 0.1f); p.set(ColorProfile.SHAD, 0.2f); p.set(ColorProfile.GREEN, 0.3f) }
    }
    return p
}
