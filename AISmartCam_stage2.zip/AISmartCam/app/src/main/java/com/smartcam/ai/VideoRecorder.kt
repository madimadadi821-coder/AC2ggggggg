package com.smartcam.ai

import android.media.*
import android.opengl.EGL14
import android.opengl.EGLExt
import android.opengl.EGLSurface
import android.opengl.GLES20
import android.view.Surface
import java.io.File
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicInteger

/** ضبط ویدیوی پردازش‌شده: رندر GL → MediaCodec (H.264) + میکروفون → AAC → MP4. */
class VideoRecorder(private val file: File, private val w: Int, private val h: Int,
                    private val withAudio: Boolean, private val onDone: (File) -> Unit) {
    private val venc: MediaCodec
    private val inSurface: Surface
    private var aenc: MediaCodec? = null
    private var rec: AudioRecord? = null
    private val muxer = MediaMuxer(file.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var vTrack = -1; private var aTrack = -1
    @Volatile private var muxStarted = false
    private val lock = Object()
    @Volatile private var stopReq = false
    @Volatile var finished = false
    private val pending = AtomicInteger(if (withAudio) 2 else 1)
    private var eglSurf: EGLSurface? = null
    private var firstTs = -1L; private var firstNano = 0L
    private val startNano = System.nanoTime()

    init {
        val vf = MediaFormat.createVideoFormat("video/avc", w, h).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, 20_000_000); setInteger(MediaFormat.KEY_FRAME_RATE, 30)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        }
        venc = MediaCodec.createEncoderByType("video/avc")
        venc.configure(vf, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        inSurface = venc.createInputSurface(); venc.start()
        Thread { drainVideo() }.start()
        if (withAudio) startAudio()
    }

    private fun tryStartMux() = synchronized(lock) {
        if (!muxStarted && vTrack >= 0 && (!withAudio || aTrack >= 0)) { muxer.start(); muxStarted = true; lock.notifyAll() }
    }

    private fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) = synchronized(lock) {
        var n = 0
        while (!muxStarted && n++ < 100) lock.wait(50)
        if (muxStarted) muxer.writeSampleData(track, buf, info)
    }

    private fun drainVideo() {
        val info = MediaCodec.BufferInfo()
        try {
            while (true) {
                val i = venc.dequeueOutputBuffer(info, 10_000)
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { vTrack = muxer.addTrack(venc.outputFormat); tryStartMux() }
                else if (i >= 0) {
                    val buf = venc.getOutputBuffer(i)!!
                    if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                    if (info.size > 0) { buf.position(info.offset); buf.limit(info.offset + info.size); write(vTrack, buf, info) }
                    venc.releaseOutputBuffer(i, false)
                    if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) break
                }
            }
        } catch (_: Exception) {}
        partDone()
    }

    private fun startAudio() {
        val rate = 44100
        val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        rec = AudioRecord(MediaRecorder.AudioSource.MIC, rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 2)
        val af = MediaFormat.createAudioFormat("audio/mp4a-latm", rate, 1).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
        }
        val e = MediaCodec.createEncoderByType("audio/mp4a-latm"); e.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE); e.start(); aenc = e
        rec!!.startRecording()
        Thread {
            val pcm = ByteArray(4096); val info = MediaCodec.BufferInfo(); var eosSent = false; var done = false
            try {
                while (!done) {
                    if (!eosSent) {
                        val n = if (stopReq) 0 else rec!!.read(pcm, 0, pcm.size)
                        val ii = e.dequeueInputBuffer(5000)
                        if (ii >= 0) {
                            val pts = (System.nanoTime() - startNano) / 1000
                            if (stopReq) { e.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM); eosSent = true }
                            else if (n > 0) { val b = e.getInputBuffer(ii)!!; b.clear(); b.put(pcm, 0, n); e.queueInputBuffer(ii, 0, n, pts, 0) }
                            else e.queueInputBuffer(ii, 0, 0, pts, 0)
                        }
                    }
                    while (true) {
                        val oi = e.dequeueOutputBuffer(info, 0)
                        if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { aTrack = muxer.addTrack(e.outputFormat); tryStartMux() }
                        else if (oi >= 0) {
                            val b = e.getOutputBuffer(oi)!!
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0) { b.position(info.offset); b.limit(info.offset + info.size); write(aTrack, b, info) }
                            e.releaseOutputBuffer(oi, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) { done = true; break }
                        } else break
                    }
                }
            } catch (_: Exception) {}
            try { rec?.stop(); rec?.release() } catch (_: Exception) {}
            partDone()
        }.start()
    }

    private fun partDone() {
        if (pending.decrementAndGet() == 0) {
            try { synchronized(lock) { if (muxStarted) muxer.stop() }; muxer.release() } catch (_: Exception) {}
            try { venc.stop(); venc.release() } catch (_: Exception) {}
            try { aenc?.stop(); aenc?.release() } catch (_: Exception) {}
            onDone(file)
        }
    }

    fun stop() { stopReq = true }

    /** روی ترد GL صدا زده می‌شود. */
    fun encodeFrame(tsNs: Long, draw: () -> Unit) {
        if (finished) return
        val d = EGL14.eglGetCurrentDisplay(); val ctx = EGL14.eglGetCurrentContext()
        if (stopReq) {
            try { venc.signalEndOfInputStream() } catch (_: Exception) {}
            eglSurf?.let { EGL14.eglDestroySurface(d, it) }; inSurface.release(); finished = true; return
        }
        val od = EGL14.eglGetCurrentSurface(EGL14.EGL_DRAW); val orr = EGL14.eglGetCurrentSurface(EGL14.EGL_READ)
        if (eglSurf == null) {
            val id = IntArray(1); EGL14.eglQueryContext(d, ctx, EGL14.EGL_CONFIG_ID, id, 0)
            val cfgs = arrayOfNulls<android.opengl.EGLConfig>(1); val n = IntArray(1)
            EGL14.eglChooseConfig(d, intArrayOf(EGL14.EGL_CONFIG_ID, id[0], EGL14.EGL_NONE), 0, cfgs, 0, 1, n, 0)
            eglSurf = EGL14.eglCreateWindowSurface(d, cfgs[0], inSurface, intArrayOf(EGL14.EGL_NONE), 0)
        }
        if (firstTs < 0) { firstTs = tsNs; firstNano = System.nanoTime() }
        EGL14.eglMakeCurrent(d, eglSurf, eglSurf, ctx)
        GLES20.glViewport(0, 0, w, h); GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        draw()
        EGLExt.eglPresentationTimeANDROID(d, eglSurf, (tsNs - firstTs) + (firstNano - startNano))
        EGL14.eglSwapBuffers(d, eglSurf)
        EGL14.eglMakeCurrent(d, od, orr, ctx)
    }
}
