package com.smartcam.ai

import android.graphics.Bitmap
import android.graphics.Matrix
import android.os.SystemClock
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.segmentation.Segmentation
import com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions

data class Stats(val luma: Float, val clip: Float, val dark: Float, val r: Float, val g: Float, val b: Float,
                 val green: Float, val skin: Float, val sky: Float, val person: Float) {
    fun describe() = "luma=%.2f clip=%.1f%% dark=%.1f%% RGB=(%.2f,%.2f,%.2f) green=%.0f%% skin=%.0f%% sky=%.0f%% person=%.0f%%"
        .format(luma, clip * 100, dark * 100, r, g, b, green * 100, skin * 100, sky * 100, person * 100)
}

/** تحلیل صحنه روی فریم‌های کوچک: آمار نور/رنگ + ماسک واقعی فرد (ML Kit، داخل خود اپ و آفلاین). */
class SceneAnalyzer(private val onResult: (Stats, MaskData?) -> Unit) : ImageAnalysis.Analyzer {
    private val seg = Segmentation.getClient(
        SelfieSegmenterOptions.Builder().setDetectorMode(SelfieSegmenterOptions.STREAM_MODE).build())
    private var last = 0L

    override fun analyze(image: ImageProxy) {
        try {
            val now = SystemClock.elapsedRealtime(); if (now - last < 150) return; last = now
            val rot = image.imageInfo.rotationDegrees
            val small = Bitmap.createScaledBitmap(image.toBitmap(), 320, 240, true)
            val up = Bitmap.createBitmap(small, 0, 0, small.width, small.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
            var md: MaskData? = null; var person = 0f
            try {
                val m = Tasks.await(seg.process(InputImage.fromBitmap(up, 0)))
                val n = m.width * m.height; val buf = m.buffer; buf.rewind()
                val out = ByteArray(n); var cnt = 0
                for (i in 0 until n) { val f = buf.float; out[i] = (f.coerceIn(0f, 1f) * 255f).toInt().toByte(); if (f > 0.5f) cnt++ }
                md = MaskData(m.width, m.height, out); person = cnt.toFloat() / n
            } catch (_: Exception) {}
            onResult(compute(up, person), md)
        } finally { image.close() }
    }

    private fun compute(b: Bitmap, person: Float): Stats {
        val w = b.width; val h = b.height; val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        var sl = 0f; var sr = 0f; var sg = 0f; var sb = 0f; var clip = 0; var dark = 0; var gr = 0; var sk = 0; var sky = 0
        for (y in 0 until h) for (x in 0 until w) {
            val p = px[y * w + x]; val r = (p shr 16) and 255; val g = (p shr 8) and 255; val bl = p and 255
            val l = (0.2126f * r + 0.7152f * g + 0.0722f * bl) / 255f
            sl += l; sr += r; sg += g; sb += bl
            if (l > 0.97f) clip++; if (l < 0.08f) dark++
            if (g > 60 && g > r * 1.1f && g > bl * 1.1f) gr++
            if (r > 95 && g > 40 && bl > 20 && r > g && r > bl && (r - g) > 15) sk++
            if (y < h * 0.45f && bl > r * 1.2f && bl > g && l > 0.45f) sky++
        }
        val n = (w * h).toFloat()
        return Stats(sl / n, clip / n, dark / n, sr / n / 255f, sg / n / 255f, sb / n / 255f, gr / n, sk / n, sky / n, person)
    }
}
