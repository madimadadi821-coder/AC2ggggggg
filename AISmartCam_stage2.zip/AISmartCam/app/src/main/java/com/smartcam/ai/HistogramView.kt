package com.smartcam.ai

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class HistogramView(c: Context) : View(c) {
    @Volatile var bins = FloatArray(64)
    @Volatile var clip = 0f
    private val bg = Paint().apply { color = Color.argb(120, 0, 0, 0) }
    private val bar = Paint().apply { color = Color.WHITE }
    private val txt = Paint().apply { color = Color.WHITE; textSize = 22f }
    fun update(b: FloatArray, cl: Float) { bins = b; clip = cl; postInvalidate() }
    override fun onDraw(cv: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        cv.drawRect(0f, 0f, w, h, bg)
        val bw = w / 64f
        for (i in 0 until 64) { val v = Math.sqrt(bins[i].toDouble()).toFloat() * (h - 26f); cv.drawRect(i * bw, h - v, (i + 1) * bw - 1f, h, bar) }
        bar.color = if (clip > 1f) Color.RED else Color.WHITE
        cv.drawText("clip %.1f%%".format(clip), 6f, 22f, txt)
        bar.color = Color.WHITE
    }
}
