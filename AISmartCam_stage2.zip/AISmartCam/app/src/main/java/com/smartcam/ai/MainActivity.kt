package com.smartcam.ai

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.SurfaceTexture
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CaptureRequest
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.provider.MediaStore
import android.view.MotionEvent
import android.view.Surface
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.camera2.interop.Camera2CameraControl
import androidx.camera.camera2.interop.Camera2CameraInfo
import androidx.camera.camera2.interop.CaptureRequestOptions
import androidx.camera.camera2.interop.ExperimentalCamera2Interop
import androidx.camera.core.*
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import java.io.File
import java.util.concurrent.Executors
import kotlin.math.ln
import kotlin.math.pow
import com.smartcam.ai.ColorProfile as P

@OptIn(ExperimentalCamera2Interop::class)
class MainActivity : ComponentActivity() {
    private lateinit var glView: GLSurfaceView
    private lateinit var renderer: CameraRenderer
    private lateinit var hist: HistogramView
    private lateinit var logView: TextView
    private lateinit var statsView: TextView
    private lateinit var recBtn: Button
    private val panels = ArrayList<View>()
    private var profile = ColorProfile()
    private val sliders = HashMap<Int, SeekBar>()
    private var syncing = false
    private var mode = 0
    private var surfaceTex: SurfaceTexture? = null
    private var camera: Camera? = null
    private var capture: ImageCapture? = null
    private var lut: LutData? = null
    private var lutMix = 1f
    @Volatile private var lastMask: MaskData? = null
    @Volatile private var lastStats: Stats? = null
    private val autoP = FloatArray(P.N)
    private var autoInit = false
    private var recorder: VideoRecorder? = null
    private val bg = Executors.newSingleThreadExecutor()
    private val analysisExec = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("profiles", MODE_PRIVATE) }

    // کنترل دستی دوربین
    private var manualExp = false; private var manualFocus = false
    private var iso = 100; private var shutterNs = 10_000_000L; private var focusDist = 0f
    private var isoRange: IntRange? = null; private var expRange: LongRange? = null; private var minFocus = 0f

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { startCameraIfReady() }
    private val lutPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) bg.execute {
            try {
                val l = contentResolver.openInputStream(uri)!!.use { Gl.parseCube(it) }
                lut = l; renderer.pendingLut = l; renderer.lutMix = lutMix
                toast("LUT بارگذاری شد (${l.size}³)")
            } catch (e: Exception) { toast("خطای LUT: ${e.message}") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        val need = listOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO)
            .filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }

    override fun onResume() { super.onResume(); glView.onResume() }
    override fun onPause() { glView.onPause(); super.onPause() }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun label(t: String) = TextView(this).apply { text = t; setTextColor(Color.WHITE); setPadding(dp(8), dp(4), 0, 0) }
    private fun row(vararg v: View) = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; v.forEach { addView(it, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f)) } }

    private fun slider(idx: Int, parent: LinearLayout, name: String) {
        parent.addView(label(name))
        val sb = SeekBar(this).apply {
            max = 200
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (syncing || !fromUser) return
                    profile.set(idx, P.MIN[idx] + p / 200f * (P.MAX[idx] - P.MIN[idx])); push()
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        sliders[idx] = sb; parent.addView(sb)
    }

    private fun simpleSlider(parent: LinearLayout, name: String, onChange: (Float) -> Unit) {
        parent.addView(label(name))
        parent.addView(SeekBar(this).apply {
            max = 100
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) onChange(p / 100f) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        })
    }

    private fun check(parent: LinearLayout, t: String, f: (Boolean) -> Unit) =
        parent.addView(CheckBox(this).apply { text = t; setTextColor(Color.WHITE); setOnCheckedChangeListener { _, b -> f(b) } })

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(Color.BLACK) }
        renderer = CameraRenderer { st -> surfaceTex = st; runOnUiThread { startCameraIfReady() } }
        glView = GLSurfaceView(this).apply {
            setEGLContextClientVersion(2); setEGLConfigChooser(RecordableChooser())
            setRenderer(renderer); renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
        }
        hist = HistogramView(this)
        renderer.onHistogram = { b, c -> hist.update(b, c) }
        val sw = resources.displayMetrics.widthPixels
        val frame = FrameLayout(this)
        frame.addView(glView, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        frame.addView(hist, FrameLayout.LayoutParams(dp(130), dp(56)).apply { leftMargin = dp(8); topMargin = dp(8) })
        statsView = TextView(this).apply { setTextColor(Color.WHITE); textSize = 10f; setBackgroundColor(Color.argb(110, 0, 0, 0)) }
        frame.addView(statsView, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, android.view.Gravity.BOTTOM))
        root.addView(frame, LinearLayout.LayoutParams(sw, sw * 4 / 3))

        val hs = HorizontalScrollView(this)
        hs.addView(LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(btn("AUTO") { showMode(0) }); addView(btn("AI") { showMode(1) }); addView(btn("PRO") { showMode(2) })
            addView(btn("CINEMA") { showMode(3) }); addView(btn("LUT") { showMode(4) })
        })
        root.addView(hs)

        // ---- AI ----
        val ai = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val input = EditText(this).apply { hint = "مثلاً: سبز درختان برجسته‌تر شود، کمی گرم‌تر، پوست و لباس طبیعی بماند"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY) }
        ai.addView(input)
        val keyBox = EditText(this).apply { hint = "کلید API (اختیاری، برای درک دستور آزاد)"; setTextColor(Color.WHITE); setHintTextColor(Color.GRAY); setText(prefs.getString("apikey", "")) }
        ai.addView(keyBox)
        ai.addView(row(btn("اعمال دستور") { runCommand(input.text.toString().trim(), keyBox.text.toString().trim()); input.setText("") },
            btn("ذخیره کلید") { prefs.edit().putString("apikey", keyBox.text.toString().trim()).apply(); toast("ذخیره شد (فقط روی همین گوشی)") }))
        logView = TextView(this).apply { setTextColor(Color.LTGRAY); setPadding(dp(8), dp(4), dp(8), dp(4)) }
        ai.addView(logView)

        // ---- PRO ----
        val pro = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((i, n) in listOf(P.EXPOSURE to "Exposure", P.TEMP to "Temperature", P.TINT to "Tint", P.CONTRAST to "Contrast",
            P.SAT to "Saturation", P.VIB to "Vibrance", P.HIGH to "Highlights", P.SHAD to "Shadows",
            P.GREEN to "Green", P.BLUE to "Blue", P.SKIN to "Skin protect")) slider(i, pro, n)
        pro.addView(label("— ابزار نمایش —"))
        check(pro, "Zebra (هایلایت‌های سوخته)") { renderer.zebra = it }
        check(pro, "False Color") { renderer.falseColor = it }
        pro.addView(label("— کنترل دستی دوربین —"))
        check(pro, "ISO / شاتر دستی") { manualExp = it; applyManual() }
        simpleSlider(pro, "ISO") { v -> isoRange?.let { r -> iso = (r.first * (r.last.toFloat() / r.first).pow(v)).toInt(); applyManual() } }
        simpleSlider(pro, "Shutter (۱/۸۰۰۰ تا ۱/۴ ثانیه)") { v -> shutterNs = (125_000.0 * (250_000_000.0 / 125_000.0).pow(v.toDouble())).toLong().let { s -> expRange?.let { r -> s.coerceIn(r.first, r.last) } ?: s }; applyManual() }
        check(pro, "فوکوس دستی") { manualFocus = it; applyManual() }
        simpleSlider(pro, "Focus (دور ← نزدیک)") { v -> focusDist = v * minFocus; applyManual() }

        // ---- CINEMA ----
        val cine = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (n in PRESET_NAMES) cine.addView(btn(n) { setProfile(presetProfile(n)); toast(n) })
        cine.addView(label("بعد از انتخاب پریست، در PRO یا AI می‌توانید آن را ریز-تنظیم کنید."))

        // ---- LUT ----
        val lp = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        lp.addView(btn("انتخاب فایل LUT (.cube)") { lutPicker.launch(arrayOf("*/*")) })
        lp.addView(btn("حذف LUT") { lut = null; renderer.clearLut = true; renderer.lutMix = 0f })
        simpleSlider(lp, "شدت LUT") { lutMix = it; if (lut != null) renderer.lutMix = it }

        panels.addAll(listOf(ai, pro, cine, lp))
        val pc = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        // ترتیب پنل‌ها: 1=AI 2=PRO 3=CINEMA 4=LUT
        panels.forEach { it.visibility = View.GONE; pc.addView(it) }
        root.addView(ScrollView(this).apply { addView(pc) }, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))

        val before = Button(this).apply {
            text = "قبل/بعد"
            setOnTouchListener { _, e -> renderer.bypass = e.action == MotionEvent.ACTION_DOWN || e.action == MotionEvent.ACTION_MOVE; true }
        }
        recBtn = btn("🎥") { toggleRecord() }
        root.addView(row(before, btn("ریست") { setProfile(ColorProfile()) },
            btn("ذخیره") { prefs.edit().putString("last", profile.toJson()).apply(); toast("پروفایل ذخیره شد") },
            btn("📷") { shoot() }, recBtn))
        setContentView(root)
        prefs.getString("last", null)?.let { ColorProfile.fromJson(it) }?.let { profile = it }
        setProfile(profile); showMode(0)
    }

    private fun showMode(m: Int) {
        mode = m; autoInit = false
        panels.forEachIndexed { i, v -> v.visibility = if (i + 1 == m) View.VISIBLE else View.GONE }
        if (m == 0) { setProfile(ColorProfile.auto()); logView.text = "" }
    }

    private fun push() { renderer.target = profile.v.copyOf() }

    private fun setProfile(p: ColorProfile) {
        profile = p; syncing = true
        for ((i, sb) in sliders) sb.progress = (((p.v[i] - P.MIN[i]) / (P.MAX[i] - P.MIN[i])) * 200).toInt()
        syncing = false; push()
    }

    // ---------- دستور متنی ----------
    private fun runCommand(text: String, key: String) {
        if (text.isEmpty()) return
        val stats = lastStats?.describe() ?: "n/a"
        logView.text = "در حال تحلیل…"
        bg.execute {
            val cur = profile.copy()
            var done = false
            if (key.isNotEmpty()) {
                try {
                    val (p, why) = LlmClient.request(key, text, cur, stats)
                    runOnUiThread { setProfile(p); logView.text = "🤖 $why" }; done = true
                } catch (e: Exception) { runOnUiThread { logView.text = "آنلاین ناموفق (${e.message?.take(80)}) ← تحلیل آفلاین" } }
            }
            if (!done) {
                val p = cur.copy(); val r = CommandParser.apply(text, p)
                runOnUiThread {
                    if (r.isEmpty()) logView.text = (if (key.isEmpty()) "" else logView.text.toString() + "\n") + "دستور را متوجه نشدم. برای درک جملات آزاد کلید API وارد کنید، یا مثلاً بنویسید: «کمی گرم‌تر»، «سبز بیشتر»، «سینمایی‌تر»."
                    else { setProfile(p); logView.text = "اعمال شد (آفلاین):\n• " + r.joinToString("\n• ") }
                }
            }
        }
    }

    // ---------- Auto Engine ----------
    private fun autoAdjust(s: Stats) {
        val tgt = FloatArray(P.N)
        tgt[P.EXPOSURE] = ((ln(0.42f / s.luma.coerceAtLeast(0.02f)) / ln(2f)).coerceIn(-0.6f, 0.6f)) * 0.6f
        tgt[P.TEMP] = ((s.b - s.r) / (s.r + s.b + 1e-3f)).coerceIn(-0.12f, 0.12f) * 1.5f
        tgt[P.HIGH] = -(s.clip * 4f).coerceAtMost(0.5f) - 0.1f
        tgt[P.SHAD] = (s.dark * 2f).coerceAtMost(0.4f) + 0.1f
        tgt[P.CONTRAST] = 0.08f; tgt[P.VIB] = 0.15f; tgt[P.SKIN] = if (s.person > 0.02f) 0.9f else 0.7f
        if (!autoInit) { tgt.copyInto(autoP); autoInit = true } else for (i in autoP.indices) autoP[i] = autoP[i] * 0.9f + tgt[i] * 0.1f
        setProfile(ColorProfile(autoP.copyOf()))
    }

    // ---------- دوربین ----------
    private fun startCameraIfReady() {
        val st = surfaceTex ?: return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) return
        val exec = ContextCompat.getMainExecutor(this)
        val f = ProcessCameraProvider.getInstance(this)
        f.addListener({
            val provider = f.get()
            val rs = ResolutionSelector.Builder().setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY).build()
            val preview = Preview.Builder().setResolutionSelector(rs).build()
            preview.setSurfaceProvider(exec) { req ->
                st.setDefaultBufferSize(req.resolution.width, req.resolution.height)
                req.setTransformationInfoListener(exec) { info -> renderer.rotation = info.rotationDegrees }
                val s = Surface(st); req.provideSurface(s, exec) { s.release() }
            }
            val analysis = ImageAnalysis.Builder().setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            analysis.setAnalyzer(analysisExec, SceneAnalyzer { stats, mask ->
                lastStats = stats; if (mask != null) { lastMask = mask; renderer.pendingMask = mask }
                runOnUiThread { statsView.text = stats.describe(); if (mode == 0) autoAdjust(stats) }
            })
            val cap = ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).setResolutionSelector(rs).build()
            provider.unbindAll()
            val cam = provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis, cap)
            camera = cam; capture = cap
            val ci = Camera2CameraInfo.from(cam.cameraInfo)
            ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE)?.let { isoRange = it.lower..it.upper }
            ci.getCameraCharacteristic(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE)?.let { expRange = it.lower..it.upper }
            minFocus = ci.getCameraCharacteristic(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        }, exec)
    }

    private fun applyManual() {
        val cam = camera ?: return
        val b = CaptureRequestOptions.Builder()
        if (manualExp) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_OFF)
            b.setCaptureRequestOption(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.setCaptureRequestOption(CaptureRequest.SENSOR_EXPOSURE_TIME, shutterNs)
        }
        if (manualFocus) {
            b.setCaptureRequestOption(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_OFF)
            b.setCaptureRequestOption(CaptureRequest.LENS_FOCUS_DISTANCE, focusDist)
        }
        Camera2CameraControl.from(cam.cameraControl).setCaptureRequestOptions(b.build())
    }

    // ---------- عکس با رزولوشن کامل ----------
    private fun shoot() {
        val cap = capture ?: return
        toast("در حال پردازش…")
        cap.takePicture(bg, object : ImageCapture.OnImageCapturedCallback() {
            override fun onCaptureSuccess(image: ImageProxy) {
                try {
                    val buf = image.planes[0].buffer; val bytes = ByteArray(buf.remaining()); buf.get(bytes)
                    val rot = image.imageInfo.rotationDegrees
                    var bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (rot != 0) bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot.toFloat()) }, true)
                    val out = OfflineProcessor.process(bmp, profile.v.copyOf(), maskFor(bmp), lut, lutMix)
                    save(out); toast("عکس ذخیره شد: Pictures/AISmartCam (${out.width}×${out.height})")
                } catch (e: Exception) { toast("خطا: ${e.message}") } finally { image.close() }
            }
            override fun onError(e: ImageCaptureException) { toast("خطای عکس: ${e.message}") }
        })
    }

    /** ماسک فرد را روی خود عکس دوباره حساب می‌کند تا محافظت پوست/لباس با پیش‌نمایش یکی باشد. */
    private fun maskFor(bmp: Bitmap): MaskData? = try {
        val small = Bitmap.createScaledBitmap(bmp, 480, (480f * bmp.height / bmp.width).toInt(), true)
        val seg = com.google.mlkit.vision.segmentation.Segmentation.getClient(
            com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions.Builder()
                .setDetectorMode(com.google.mlkit.vision.segmentation.selfie.SelfieSegmenterOptions.SINGLE_IMAGE_MODE).build())
        val m = com.google.android.gms.tasks.Tasks.await(seg.process(com.google.mlkit.vision.common.InputImage.fromBitmap(small, 0)))
        val n = m.width * m.height; val b = m.buffer; b.rewind(); val o = ByteArray(n)
        for (i in 0 until n) o[i] = (b.float.coerceIn(0f, 1f) * 255f).toInt().toByte()
        MaskData(m.width, m.height, o)
    } catch (_: Exception) { null }

    private fun save(bmp: Bitmap) {
        val cv = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "AISC_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/AISmartCam")
        }
        val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv) ?: return
        contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.JPEG, 96, it) }
    }

    // ---------- ویدیو ----------
    private fun toggleRecord() {
        val r = recorder
        if (r == null) {
            try {
                val f = File(cacheDir, "rec_${System.currentTimeMillis()}.mp4")
                val audio = checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                val nr = VideoRecorder(f, 1080, 1440, audio) { file -> saveVideo(file) }
                recorder = nr; renderer.recorder = nr; recBtn.text = "⏹"
            } catch (e: Exception) { toast("شروع ضبط ناموفق: ${e.message}") }
        } else { r.stop(); recorder = null; recBtn.text = "🎥"; toast("در حال نهایی‌سازی ویدیو…") }
    }

    private fun saveVideo(file: File) {
        try {
            val cv = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, "AISC_${System.currentTimeMillis()}.mp4")
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/AISmartCam")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { o -> file.inputStream().use { it.copyTo(o) } }
            file.delete(); toast("ویدیو ذخیره شد: Movies/AISmartCam")
        } catch (e: Exception) { toast("ذخیره ویدیو ناموفق: ${e.message}") }
    }
}
