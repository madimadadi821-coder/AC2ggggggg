package com.smartcam.ai

import com.smartcam.ai.ColorProfile as P

/** تحلیل‌گر آفلاین دستور فارسی/انگلیسی. مرحله بعد: LLM آنلاین با خروجی JSON، این کلاس می‌شود fallback. */
object CommandParser {
    private val SMALL = listOf("کمی", "اندکی", "slightly", "a bit", "little")
    private val BIG = listOf("خیلی", "بسیار", "زیاد", "much", "very", "strong")
    private val DOWN = listOf("کاهش", "کمتر", "کم کن", "ضعیف", "کمرنگ", "reduce", "less", "lower", "decrease", "down")

    private fun norm(s: String) = s.lowercase().replace('ي', 'ی').replace('ك', 'ک')
        .replace("\u200c", "").replace("ـ", "")

    fun apply(raw: String, p: ColorProfile): List<String> {
        val out = mutableListOf<String>()
        for (cl in norm(raw).split(Regex("[،,.;\\n]|ولی|اما|\\bbut\\b"))) {
            val c = cl.trim(); if (c.isEmpty()) continue
            fun has(vararg k: String) = k.any { c.contains(it) }
            val mag = when { has(*SMALL.toTypedArray()) -> 0.2f; has(*BIG.toTypedArray()) -> 0.6f; else -> 0.4f }
            val dir = if (has(*DOWN.toTypedArray())) -1f else 1f
            val skin = has("پوست", "skin")

            if (skin && has("طبیعی", "natural", "حفظ", "بماند", "باقی")) { p.set(P.SKIN, 1f); out += "محافظت رنگ پوست: حداکثر" }
            if (skin && has("گرم", "warm")) { p.add(P.WARMSKIN, mag * 0.8f); out += "پوست گرم‌تر" }
            if (has("سبز", "green", "برگ", "درخت", "گیاه")) { p.add(P.GREEN, dir * mag * 1.5f); out += "سبزها ${if (dir > 0) "برجسته‌تر" else "کم‌رنگ‌تر"} (پوست محافظت‌شده)" }
            if (has("آبی", "blue")) { p.add(P.BLUE, dir * mag * 1.5f); out += "آبی‌ها ${if (dir > 0) "عمیق‌تر" else "ملایم‌تر"}" }
            if (!skin && has("گرم", "warm")) { p.add(P.TEMP, mag * 0.6f); out += "دمای رنگ گرم‌تر" }
            if (has("سرد", "cool", "cold")) { p.add(P.TEMP, -mag * 0.6f); out += "دمای رنگ سردتر" }
            if (has("سینمایی", "cinematic")) {
                p.add(P.CONTRAST, 0.25f); p.add(P.SAT, -0.12f); p.add(P.SHAD, -0.2f); p.add(P.HIGH, -0.1f); p.add(P.TEMP, 0.08f)
                out += "ظاهر سینمایی: کنتراست بیشتر، اشباع و سایه‌ها کمتر"
            }
            if (has("آیفون", "iphone")) {
                p.add(P.CONTRAST, 0.1f); p.add(P.VIB, 0.15f); p.add(P.SHAD, 0.12f); p.add(P.HIGH, -0.12f); p.add(P.TEMP, 0.05f)
                out += "استایل نزدیک به آیفون (تقریبی): کنتراست ملایم، سایه باز، هایلایت کنترل‌شده"
            }
            if (has("کنتراست", "contrast")) { p.add(P.CONTRAST, dir * mag); out += "کنتراست ${if (dir > 0) "+" else "−"}" }
            if (has("اشباع", "saturation")) { p.add(P.SAT, dir * mag); out += "اشباع ${if (dir > 0) "+" else "−"}" }
            if (has("سایه", "shadow")) {
                val d = if (has("تاریک", "dark")) -1f else if (has("روشن", "باز", "lift")) 1f else 0f
                if (d != 0f) { p.add(P.SHAD, d * mag); out += "سایه‌ها ${if (d > 0) "روشن‌تر" else "تاریک‌تر"}" }
            } else if (has("روشن", "bright")) { p.add(P.EXPOSURE, dir * mag * 1.2f); out += "نوردهی ${if (dir > 0) "+" else "−"}" }
            else if (has("تاریک", "dark")) { p.add(P.EXPOSURE, -mag * 1.2f); out += "نوردهی −" }
            if (has("هایلایت", "highlight", "نور شدید", "نورهای شدید", "نسوز", "بسوز")) { p.add(P.HIGH, -mag * 1.5f); out += "کنترل هایلایت‌ها" }
        }
        return out
    }
}
