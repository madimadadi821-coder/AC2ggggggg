package com.smartcam.ai

import android.opengl.GLES20
import android.opengl.Matrix
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer

class LutData(val size: Int, val rgb: ByteArray)
class MaskData(val w: Int, val h: Int, val data: ByteArray)

object Gl {
    const val OES = 0x8D65
    // ترتیب رأس‌ها: BL, BR, TL, TR. کلید = چرخش ساعتگرد لازم برای ایستادن تصویر
    val UV = mapOf(
        0 to floatArrayOf(0f, 0f, 1f, 0f, 0f, 1f, 1f, 1f),
        90 to floatArrayOf(1f, 0f, 1f, 1f, 0f, 0f, 0f, 1f),
        180 to floatArrayOf(1f, 1f, 0f, 1f, 1f, 0f, 0f, 0f),
        270 to floatArrayOf(0f, 1f, 0f, 0f, 1f, 1f, 1f, 0f))

    fun quad(uv: FloatArray): FloatBuffer {
        val pos = floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)
        val d = FloatArray(16)
        for (i in 0..3) { d[i * 4] = pos[i * 2]; d[i * 4 + 1] = pos[i * 2 + 1]; d[i * 4 + 2] = uv[i * 2]; d[i * 4 + 3] = uv[i * 2 + 1] }
        return ByteBuffer.allocateDirect(64).order(ByteOrder.nativeOrder()).asFloatBuffer().apply { put(d); position(0) }
    }

    fun tex2d(): Int {
        val t = IntArray(1); GLES20.glGenTextures(1, t, 0)
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, t[0])
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES20.GL_TEXTURE_2D, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        return t[0]
    }

    private fun direct(b: ByteArray): ByteBuffer = ByteBuffer.allocateDirect(b.size).order(ByteOrder.nativeOrder()).apply { put(b); position(0) }

    fun uploadMask(tex: Int, m: MaskData) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex); GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_LUMINANCE, m.w, m.h, 0, GLES20.GL_LUMINANCE, GLES20.GL_UNSIGNED_BYTE, direct(m.data))
    }

    fun uploadLut(tex: Int, l: LutData) {
        GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, tex); GLES20.glPixelStorei(GLES20.GL_UNPACK_ALIGNMENT, 1)
        GLES20.glTexImage2D(GLES20.GL_TEXTURE_2D, 0, GLES20.GL_RGB, l.size * l.size, l.size, 0, GLES20.GL_RGB, GLES20.GL_UNSIGNED_BYTE, direct(l.rgb))
    }

    fun blackPixel(tex: Int) = uploadMask(tex, MaskData(1, 1, ByteArray(1)))

    /** فایل .cube سه‌بعدی را به نوار دوبعدی (N*N × N) تبدیل می‌کند. */
    fun parseCube(ins: InputStream): LutData {
        var n = 0; val vals = ArrayList<Float>()
        ins.bufferedReader().forEachLine { l ->
            val t = l.trim()
            if (t.isEmpty() || t.startsWith("#")) return@forEachLine
            when {
                t.startsWith("LUT_3D_SIZE") -> n = t.split(Regex("\\s+"))[1].toInt()
                t.startsWith("LUT_1D_SIZE") -> throw IllegalArgumentException("LUT یک‌بعدی پشتیبانی نمی‌شود")
                t[0].isDigit() || t[0] == '-' || t[0] == '.' -> {
                    val p = t.split(Regex("\\s+"))
                    if (p.size >= 3) { vals.add(p[0].toFloat()); vals.add(p[1].toFloat()); vals.add(p[2].toFloat()) }
                }
            }
        }
        require(n > 1 && vals.size == n * n * n * 3) { "فایل cube نامعتبر است" }
        val out = ByteArray(n * n * n * 3)
        for (b in 0 until n) for (g in 0 until n) for (r in 0 until n) {
            val s = (r + g * n + b * n * n) * 3; val d = (g * n * n + b * n + r) * 3
            for (k in 0..2) out[d + k] = (vals[s + k].coerceIn(0f, 1f) * 255f + 0.5f).toInt().toByte()
        }
        return LutData(n, out)
    }

    fun link(vs: String, fs: String): Int {
        fun sh(type: Int, src: String): Int {
            val s = GLES20.glCreateShader(type); GLES20.glShaderSource(s, src); GLES20.glCompileShader(s)
            val ok = IntArray(1); GLES20.glGetShaderiv(s, GLES20.GL_COMPILE_STATUS, ok, 0)
            if (ok[0] == 0) throw RuntimeException("Shader: " + GLES20.glGetShaderInfoLog(s))
            return s
        }
        val p = GLES20.glCreateProgram()
        GLES20.glAttachShader(p, sh(GLES20.GL_VERTEX_SHADER, vs)); GLES20.glAttachShader(p, sh(GLES20.GL_FRAGMENT_SHADER, fs))
        GLES20.glLinkProgram(p); return p
    }
}

/** یک برنامهٔ شیدر کامل (پیش‌نمایش با OES، یا پردازش تصویر کامل با sampler2D). */
class Pipeline(private val external: Boolean) {
    private val prog = Gl.link(VS, fragment(external))
    private fun u(n: String) = GLES20.glGetUniformLocation(prog, n)
    private val aPos = GLES20.glGetAttribLocation(prog, "aPos")
    private val aUv = GLES20.glGetAttribLocation(prog, "aUv")
    private val uStm = u("uStm"); private val uFlip = u("uMaskFlip"); private val uP = u("uP")
    private val uBypass = u("uBypass"); private val uHasMask = u("uHasMask"); private val uLutMix = u("uLutMix")
    private val uLutSize = u("uLutSize"); private val uZebra = u("uZebra"); private val uFalse = u("uFalse")
    private val uTex = u("uTex"); private val uMask = u("uMask"); private val uLut = u("uLutTex")
    private val ident = FloatArray(16).also { Matrix.setIdentityM(it, 0) }

    fun draw(p: FloatArray, quad: FloatBuffer, stm: FloatArray?, srcTex: Int, maskTex: Int, lutTex: Int,
             bypass: Boolean, hasMask: Boolean, lutMix: Float, lutSize: Int, zebra: Boolean, falseColor: Boolean, maskFlip: Boolean) {
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(if (external) Gl.OES else GLES20.GL_TEXTURE_2D, srcTex)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE1); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, maskTex)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE2); GLES20.glBindTexture(GLES20.GL_TEXTURE_2D, lutTex)
        GLES20.glUniform1i(uTex, 0); GLES20.glUniform1i(uMask, 1); GLES20.glUniform1i(uLut, 2)
        GLES20.glUniformMatrix4fv(uStm, 1, false, stm ?: ident, 0)
        GLES20.glUniform1fv(uP, ColorProfile.N, p, 0)
        GLES20.glUniform1f(uBypass, if (bypass) 1f else 0f); GLES20.glUniform1f(uHasMask, if (hasMask) 1f else 0f)
        GLES20.glUniform1f(uLutMix, lutMix); GLES20.glUniform1f(uLutSize, lutSize.toFloat())
        GLES20.glUniform1f(uZebra, if (zebra) 1f else 0f); GLES20.glUniform1f(uFalse, if (falseColor) 1f else 0f)
        GLES20.glUniform1f(uFlip, if (maskFlip) 1f else 0f)
        quad.position(0); GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(aPos)
        quad.position(2); GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 16, quad); GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
    }

    companion object {
        private const val VS = """
uniform mat4 uStm; uniform float uMaskFlip; attribute vec2 aPos; attribute vec2 aUv;
varying vec2 vUv; varying vec2 vMask;
void main(){
  gl_Position = vec4(aPos, 0.0, 1.0);
  vUv = (uStm * vec4(aUv, 0.0, 1.0)).xy;
  float my = (uMaskFlip > 0.5) ? (aPos.y * 0.5 + 0.5) : (0.5 - aPos.y * 0.5);
  vMask = vec2(aPos.x * 0.5 + 0.5, my);
}"""

        fun fragment(external: Boolean): String {
            val head = if (external) "#extension GL_OES_EGL_image_external : require\n" else ""
            val sampler = if (external) "samplerExternalOES" else "sampler2D"
            return head + "precision highp float;\nvarying vec2 vUv; varying vec2 vMask;\nuniform $sampler uTex;\n" + FS_BODY
        }

        // uP: 0 exposure,1 temp,2 tint,3 contrast,4 sat,5 vib,6 high,7 shad,8 green,9 blue,10 skinProtect,11 warmSkin
        private const val FS_BODY = """
uniform sampler2D uMask; uniform sampler2D uLutTex;
uniform float uP[12];
uniform float uBypass; uniform float uHasMask; uniform float uLutMix; uniform float uLutSize;
uniform float uZebra; uniform float uFalse;
vec3 rgb2hsv(vec3 c){
  vec4 K=vec4(0.0,-1.0/3.0,2.0/3.0,-1.0);
  vec4 p=mix(vec4(c.bg,K.wz),vec4(c.gb,K.xy),step(c.b,c.g));
  vec4 q=mix(vec4(p.xyw,c.r),vec4(c.r,p.yzx),step(p.x,c.r));
  float d=q.x-min(q.w,q.y); float e=1.0e-7;
  return vec3(abs(q.z+(q.w-q.y)/(6.0*d+e)), d/(q.x+e), q.x);
}
vec3 hsv2rgb(vec3 c){
  vec4 K=vec4(1.0,2.0/3.0,1.0/3.0,3.0);
  vec3 p=abs(fract(c.xxx+K.xyz)*6.0-K.www);
  return c.z*mix(K.xxx,clamp(p-K.xxx,0.0,1.0),c.y);
}
vec3 lut(vec3 c){
  float N=uLutSize; c=clamp(c,0.0,1.0);
  float b=c.b*(N-1.0); float b0=floor(b); float b1=min(b0+1.0,N-1.0); float f=b-b0;
  float x=c.r*(N-1.0)+0.5; float y=(c.g*(N-1.0)+0.5)/N;
  vec3 a0=texture2D(uLutTex,vec2((b0*N+x)/(N*N),y)).rgb;
  vec3 a1=texture2D(uLutTex,vec2((b1*N+x)/(N*N),y)).rgb;
  return mix(a0,a1,f);
}
vec3 falseCol(float l){
  if(l<0.03) return vec3(0.45,0.0,0.65);
  if(l<0.15) return vec3(0.0,0.1,0.9);
  if(l<0.35) return vec3(0.0,0.6,0.6);
  if(l<0.50) return vec3(0.5);
  if(l<0.65) return vec3(1.0,0.6,0.7);
  if(l<0.85) return vec3(1.0,0.9,0.0);
  if(l<0.95) return vec3(1.0,0.5,0.0);
  return vec3(1.0,0.0,0.0);
}
void main(){
  vec3 src = texture2D(uTex, vUv).rgb;
  if(uBypass > 0.5){ gl_FragColor = vec4(src,1.0); return; }
  float pers = (uHasMask > 0.5) ? texture2D(uMask, vMask).r : 0.0;
  vec3 base = clamp(src * exp2(uP[0]), 0.0, 1.0);
  vec3 c = base;
  c.r *= 1.0 + uP[1]*0.2; c.b *= 1.0 - uP[1]*0.2; c.g *= 1.0 - uP[2]*0.15;
  float l = dot(c, vec3(0.2126,0.7152,0.0722));
  c += (1.0 - smoothstep(0.0,0.5,l)) * uP[7] * 0.25;
  c += smoothstep(0.5,1.0,l) * uP[6] * 0.25;
  c = clamp((c - 0.5) * (1.0 + uP[3]) + 0.5, 0.0, 1.0);
  vec3 hsv = rgb2hsv(c);
  float h=hsv.x, s=hsv.y, v=hsv.z;
  float skinH = max(1.0-smoothstep(0.07,0.12,h), smoothstep(0.96,0.99,h))
              * smoothstep(0.12,0.25,s) * (1.0-smoothstep(0.65,0.8,s)) * smoothstep(0.2,0.35,v);
  float skinW = (uHasMask > 0.5) ? skinH * pers : skinH;
  float prot = ((uHasMask > 0.5) ? pers : skinH) * uP[10];
  float green = smoothstep(0.17,0.22,h)*(1.0-smoothstep(0.42,0.47,h))*smoothstep(0.1,0.25,s);
  float blue  = smoothstep(0.50,0.55,h)*(1.0-smoothstep(0.68,0.74,h))*smoothstep(0.1,0.25,s);
  s *= 1.0 + uP[8]*green*(1.0-prot)*0.6;
  v *= 1.0 - uP[8]*green*(1.0-prot)*0.05;
  s *= 1.0 + uP[9]*blue*(1.0-prot)*0.6;
  v *= 1.0 - uP[9]*blue*(1.0-prot)*0.10;
  s *= 1.0 + uP[4];
  s *= 1.0 + uP[5]*(1.0-s)*(1.0-prot*0.5);
  c = hsv2rgb(vec3(h, clamp(s,0.0,1.0), clamp(v,0.0,1.0)));
  c = mix(c, base, prot*0.6);
  c.r += uP[11]*skinW*0.06; c.b -= uP[11]*skinW*0.06;
  c = clamp(c,0.0,1.0);
  if(uLutMix > 0.0) c = mix(c, lut(c), uLutMix);
  float lo = dot(c, vec3(0.2126,0.7152,0.0722));
  if(uFalse > 0.5) c = falseCol(lo);
  else if(uZebra > 0.5 && lo > 0.94 && mod(floor(gl_FragCoord.x+gl_FragCoord.y),16.0) < 8.0) c = vec3(0.0);
  gl_FragColor = vec4(c, 1.0);
}"""
    }
}
