package com.smartcam.ai

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

/** درک دستور آزاد فارسی/انگلیسی با Claude. فقط متن دستور و آمار عددی صحنه ارسال می‌شود، نه تصویر. */
object LlmClient {
    const val MODEL = "claude-sonnet-5-5"

    private val SYSTEM = """
You control a live camera color-grading engine. The user gives a Persian or English instruction.
You receive the CURRENT profile and numeric scene statistics (no image). Return ONLY a JSON object:
{"profile": {...}, "explanation": "<short Persian description of what you changed and why>"}
"profile" holds the FINAL absolute values (not deltas) for any of these keys, other keys keep the current value:
exposure (-2..2 EV), temperature (-1 cool..1 warm), tint (-1 green..1 magenta), contrast (-1..1), saturation (-1..1),
vibrance (-1..1), highlights (-1..1; negative recovers bright areas), shadows (-1..1; positive lifts), green (-1..1; boosts
foliage/green only, people are protected), blue (-1..1; deepens blues/sky), skinProtect (0..1; keeps people and skin natural),
warmSkin (-1..1; warms skin of people only).
Use moderate values: typical changes are 0.1-0.5. Never output text outside the JSON object.
Use the scene stats to choose sensible magnitudes (e.g. clip>3% means highlights need recovery).
""".trimIndent()

    fun request(key: String, text: String, cur: ColorProfile, stats: String): Pair<ColorProfile, String> {
        val body = JSONObject().apply {
            put("model", MODEL); put("max_tokens", 600); put("system", SYSTEM)
            put("messages", JSONArray().put(JSONObject().apply {
                put("role", "user")
                put("content", "Current profile: ${cur.toJson()}\nScene stats: $stats\nInstruction: $text")
            }))
        }
        val c = URL("https://api.anthropic.com/v1/messages").openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 10_000; c.readTimeout = 30_000; c.doOutput = true
        c.setRequestProperty("x-api-key", key); c.setRequestProperty("anthropic-version", "2023-06-01")
        c.setRequestProperty("content-type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val code = c.responseCode
        val resp = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().readText()
        if (code !in 200..299) throw RuntimeException("HTTP $code: " + resp.take(200))
        val txt = JSONObject(resp).getJSONArray("content").getJSONObject(0).getString("text")
        val j = JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1))
        val prof = ColorProfile.fromJsonMerge(cur, j.getJSONObject("profile"))
        return prof to j.optString("explanation", "")
    }
}
